def add_dict_list(dic, ls, val):
    for x in ls:
        dic[x] = val\
            