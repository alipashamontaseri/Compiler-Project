SYMBOLS = list(';:,[](){}+-*=</')
WHITESPACES = [chr(32), chr(10), chr(13), chr(9), chr(11), chr(12)]
NUM = list('0123456789')
ID = list('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ')
KEYWORDS = ['if', 'else', 'void', 'int', 'while', 'break', 'return']